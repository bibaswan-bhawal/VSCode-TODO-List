# Change Log

All notable changes to the "vscode-todo-list" extension will be documented in this file.

## [Unreleased]

### Added
